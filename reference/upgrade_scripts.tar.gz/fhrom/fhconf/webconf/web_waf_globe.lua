
if denycc() then
elseif url() then
elseif referers() then
elseif args() then
elseif cookie() then
elseif body() then
else
    local uri = ngx.var.uri

    local user = ngx.req.get_login_res()

    ngx.var.login_user = user

    local operator_name = ngx.req.get_operator_name()

    local area_code = ngx.req.get_area_code()

    ------------------ 文件权限控制 begin ------------------
    if string.find(uri, "^/src/") == 1 or uri == "/main.html" then

        -- 访问文件列表begin --
        publicList = "main.html, main.js, index.js, footerComp.js, headerComp.js, menudata.js, router.js, validation.js\
            sidenavComp.js, confirmComp.js, deleteComp.js, macFilterComp.js, macReservComp.js, dashboardStatus.js, networkInfo.js,\
            basic.js, advanced.js, dhcpIPv4.js, dhcpIPv6.js, macReservation.js, macFilter.js, simInfo.js, carrierAggregation.js,\
            firewall.js, parentalControl.js, maintenance.js, algSet.js, smsNew.js, smsInbox.js,"
        list_3 = "networkConn.js, acsServer.js, configManage.js, networkSet.js, voiceConfig.js, cellLockSet.js, frequencyLockSet.js,\
            debugInfo.js, aclSet.js, aclSetComp.js, logManagement.js, logEnable.js"
        list_2 = "networkConn.js, acsServer.js, configManage.js, networkSet.js, voiceConfig.js, debugInfo.js, aclSet.js"

        -- 访问文件列表end --

        userPagesAccessControl(publicList, _G["list_"..user], _G[operator_name.."_"..area_code], _G[operator_name.."_"..area_code.."_"..user], _G[operator_name.."_"..area_code.."_del"], _G[operator_name.."_"..area_code.."_"..user.."_del"], uri, user, operator_name, area_code)
    end
    ------------------ 文件权限控制 end ------------------

    ------------------ 接口权限控制 begin ------------------
    
    if uri == "/cgi-bin/adbdebug" or uri == "/cgi-bin/plusdebug" then
        if user ~= 3 then 
            log('user no premission', "-", uri, user)
            ngx.exit(403)
        end
    end

    -- /fh_api/download/  文件下载接口 --
    if string.find(uri, "^/fh_api/download/") == 1 then
        local user_no_useragent = ngx.req.get_login_res_no_useragent()
        if user_no_useragent == 0  then 
            ngx.exit(403)
        end
    end

    -- /fh_api/tmp/FHUPAPIS  升级、文件上传接口 --
    if uri == "/fh_api/tmp/FHUPAPIS" then
        if user ~= 2 then 
            log('user no premission', "-", uri, user)
            ngx.exit(403)
        end

        local query_string = ngx.var.query_string
        if query_string == "" or query_string == nil then
            log('query_string is nil', "-", uri, "-")
            ngx.exit(403)
        end

        if string.find(query_string, "action=upgradeimage") ~= nil 
            or string.find(query_string, "action=uploadprepare") ~= nil 
            or string.find(query_string, "action=chunkupload") ~= nil then
        else
            log('action no premission', "-", uri, query_string)
            ngx.exit(403)
        end
    end
    ------------------ 接口权限控制 end ------------------

    if uri == "/cgi-bin/luci" then
        ngx.redirect("/", 302)
    end

    if (uri == "/port_mirror.html" or uri == "/js/port_mirror.js") and user ~= 2 then
        ngx.exit(400)
    end

    initCustomApi(uri, user)
end
