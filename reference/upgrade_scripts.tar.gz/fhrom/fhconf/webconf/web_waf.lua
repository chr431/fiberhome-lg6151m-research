
if denycc() then
elseif url() then
elseif referers() then
elseif args() then
elseif cookie() then
elseif body() then
else
    local uri = ngx.var.uri

    local user = ngx.req.get_login_res()

    ngx.var.login_user = user

    local operator_name = ngx.req.get_operator_name()

    local area_code = ngx.req.get_area_code()

    local model_name = ngx.req.get_devinfo("devicetype")

    ------------------ 文件权限控制 begin ------------------
    if string.find(uri, "^/src/") == 1 or uri == "/main.html" then

        -- 访问文件列表begin --
        publicList = "main.html, main.js, index.js, footerComp.js, headerComp.js, menudata.js, menuComp.js, router.js,home.js, deviceInfo.js, wifiStat.js, voiceSet.js, simInfo.js, configManage.js, networkSet.js,  antennaSet.js,networkInfo.js, networkConn.js, lanSet.js, ipv4Settings.js, ipv6Settings.js,  wifiBasic.js, wifiAdvanced.js,wifiBasic_5g.js, wifiAdvanced_5g.js, wps.js, neighbor.js, device.js, firewall.js, parentControl.js, macFilter.js,ipFilter.js, l2tpSet.js, pptpSet.js, ipsecSet.js, staticRoute.js, dmzSet.js, portForward.js, ping.js, traceroute.js,userAccount.js, restore.js, ntp.js, reboot.js,  help.js, trafficStat.js, factoryInfoCheck.js, developeComp.js, nfc.js, multiLink.js, multiLinkPrinciple.js, led.js, fanControl.js, natSet.js, wifiInone.js, passComp.js, pccLock.js, wifiGuest.js, logManagement.js"
        list_3 = "rfSignal.js, voiceConfig.js, atCommand.js, dhcpStaticSettings.js, acsServer.js, carrierLock.js, debugInfo.js, algSet.js, localUp.js, backupRecover.js,  portMirror.js, tr069InformStatus.js, "
        list_2 = ""

        list_1 = ""
        
        COMMON_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js, smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, netDetection.js, pinManagement.js, remoteUp.js, versionUp.js, appCode.js, privateNetwork.js, mesh.js, subrouter.js"

        COMMON_INTL_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js, smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js"
        
        COMMON_NA_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js, smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js"
        
        COMMON_EUR_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js, smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js"

        IDN_EMR_Trunk = "upnpSet.js, ddnsSet.js, rfSignalIdn.js, dhcpStaticSettings.js, smsInbox.js, cellLockBatchSet.js, pinManagementNew.js, netDetection.js"

        IDN_SURGE_Trunk = "upnpSet.js, ddnsSet.js, rfSignalIdn.js, dhcpStaticSettings.js, smsInbox.js,  cellLockBatchSet.js, pinManagementNew.js, netDetection.js"

        SA_STC_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js, smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js"

        KEN_SARAFI_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js,  smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js"
       
        LEISHEN_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, rfSignal.js, dhcpStaticSettings.js, carrierAggregation.js,  smsEnable.js,smsInbox.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, netDetection.js, pinManagement.js, remoteUp.js, versionUp.js"

        PL_PLUS_Trunk = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, backupRecover.js, rfSignal.js, dhcpStaticSettings.js,smsInbox.js, carrierAggregation.js, deviceOffline.js, cellLockSet.js, wifiAreaCode.js, pinManagement.js, remoteUp.js, volteCalls.js, versionUp.js"

        PH_PLDT_Trunk = "accountManagement.js, sms.js, rfSignal.js"

        PH_GLOBE_Trunk = "dashboardStatus.ls, "

        OMN_OMANTEL_Trunk = "sms.js, sms_send.js "

        PH_DITO_Trunk ="sms.js, sms_send.js"

        PH_PLDT_Trunk_3 = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, "
        OMN_OMANTEL_Trunk_3 = "frequencyLockSet.js, upnpSet.js, ddnsSet.js,"
        PH_DITO_Trunk_3 = "frequencyLockSet.js, upnpSet.js, ddnsSet.js, , "

        SA_STC_Trunk_del = "carrierLock.js,"

        -- 访问文件列表end --

        userPagesAccessControl(publicList, _G["list_"..user], _G[operator_name.."_"..area_code], _G[operator_name.."_"..area_code.."_"..user], _G[operator_name.."_"..area_code.."_del"], _G[operator_name.."_"..area_code.."_"..user.."_del"], uri, user, operator_name, area_code)
    end
    ------------------ 文件权限控制 end ------------------

    ------------------ 接口权限控制 begin ------------------
    
    if uri == "/cgi-bin/adbdebug" or uri == "/cgi-bin/plusdebug" then
        if user ~= 3 then 
            log('user no premission', "-", uri, user)
            ngx.exit(403)
        end
    end

    -- /fh_api/download/  文件下载接口 --
    if string.find(uri, "^/fh_api/download/") == 1 then
        local user_no_useragent = ngx.req.get_login_res_no_useragent()
        if user_no_useragent == 0  then 
            ngx.exit(403)
        end
    end

    -- /fh_api/tmp/FHUPAPIS  升级、文件上传接口 --
    if uri == "/fh_api/tmp/FHUPAPIS" then
        if user == 0 then 
            log('user no premission', "-", uri, user)
            ngx.exit(403)
        end

        local query_string = ngx.var.query_string
        if query_string == "" or query_string == nil then
            log('query_string is nil', "-", uri, "-")
            ngx.exit(403)
        end

        if string.find(query_string, "action=upgradeimage") ~= nil 
            or string.find(query_string, "action=preconfig") ~= nil 
            or string.find(query_string, "action=uploadprepare") ~= nil 
            or string.find(query_string, "action=chunkupload") ~= nil then
        else
            log('action no premission', "-", uri, query_string)
            ngx.exit(403)
        end
    end
    ------------------ 接口权限控制 end ------------------

    if uri == "/factoryInfoCheck.html" or uri == "/js/factoryInfoCheck.js" then
        if os.getenv("factoryMode") ~= "1" and user ~= 3 then
            ngx.exit(403)
        end
    end

    if uri == "/cgi-bin/luci" then
        ngx.redirect("/", 302)
    end

    if (uri == "/port_mirror.html" or uri == "/js/port_mirror.js") and user ~= 2 then
        ngx.exit(400)
    end

    if uri == "/src/content/pages/nfc.js" or uri == "/src/content/pages/antennaSet.js" or uri == "/src/content/pages/multiLink.js" then
        if model_name == "LG6151M" then
            ngx.exit(403)
        end
    end

    if uri == "/src/content/pages/accountManagement.js" or uri == "/src/content/pages/sms.js" 
        or uri == "/src/content/pages/volteCalls.js" or uri == "/src/content/pages/wifiStat.js" 
        or uri == "/src/content/pages/voiceConfig.js" or uri == "/src/content/pages/sms_send.js"
        or uri == "/src/content/pages/carrierAggregation.js" or uri == "/src/content/pages/antennaSet.js" 
        or uri == "/src/content/pages/neighbor.js" or uri == "/src/content/pages/neighbor.js" 
        or uri == "/src/content/pages/wifiGuest.js" or uri == "/src/content/pages/multiLink.js" 
        or uri == "/src/content/pages/multiLinkPrinciple.js" or uri == "/src/content/pages/mesh.js" 
        or uri == "/src/content/pages/device.js" or uri == "/src/content/pages/deviceOffline.js" 
        or uri == "/src/content/pages/subrouter.js" or uri == "/src/content/pages/aclSet.js" 
        or uri == "/src/content/pages/natSet.js" or uri == "/src/content/pages/natSet.js" 
        or uri == "/src/content/pages/carrierLock.js"or uri == "/src/content/pages/pccLock.js" 
        or uri == "/src/content/pages/privateNetwork.js" or uri == "/src/content/pages/wifiAreaCode.js" 
        or uri == "/src/content/pages/ddnsSet.js" or uri == "/src/content/pages/voiceSet.js" 
        or uri == "/src/content/pages/nfc.js" or uri == "/src/content/pages/fanControl.js"
        or uri == "/src/content/pages/remoteUp.js" or uri == "/src/content/pages/versionUp.js" 
        or uri == "/src/content/pages/ftp.js" or uri == "/src/content/pages/appCode.js" 
        or uri == "/src/content/pages/rfSignal.js" or uri == "/src/content/pages/cellLockSet.js" 
        or uri == "/src/content/pages/pinManagement.js" or uri == "/src/content/pages/smsEnable.js" 
        or uri == "/src/content/pages/debugInfo.js" then
        if model_name == "LG6120E" then
            ngx.exit(403)
        end
    end

    initCustomApi(uri, user)
end
