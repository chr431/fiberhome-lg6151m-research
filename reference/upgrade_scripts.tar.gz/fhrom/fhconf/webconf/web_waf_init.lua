attacklog=true
logpath="/var/log/web_waf.log"
rulepath="/fhrom/fhconf/webconf/web_waf_rules"
UrlDeny=true
CookieCheck=false
refererCheck=false
CCDeny=false
CCcount=100
CCseconds=10

local match=string.match
local ngxmatch=ngx.re.find
local unescape=ngx.unescape_uri

local seed = ngx.time() * 1000 + ngx.worker.id()
math.randomseed(seed)

function getClientIp()
    local IP = ngx.var.remote_addr
    if IP == nil then
        IP = "unknown"
    end
    return IP
end

function read(path)
    local fd = io.open(path, "r")
    if fd == nil then return nil end
    local buf = fd:read()
    fd:close()
    if buf == nil then
        buf = ""
    end
    return buf
end

function write(path, msg, mode)
    if path == nil or msg == nil or mode == nil then 
        return
    end
    local fd = io.open(path, mode)
    if fd == nil then return end
    fd:write(msg)
    fd:flush()
    fd:close()
end

function executeCommand(cmd)
    -- 打开命令以进行读取
    local handle = io.popen(cmd)
    if not handle then
        return ""
    end
 
    -- 读取所有输出
    local result = handle:read("*a")
 
    -- 关闭句柄
    handle:close()
 
    -- 返回命令输出
    return result
end

function randomString(length)
    local str = ""
    local charset = {"1","2","3","4","5","6","7","8","9","0","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","+","/","="}

    for i = 1, length do
        local char = charset[math.random(1, #charset)]
        str = str..char
    end
    return str
end

function getTableLens(t)
    if type(t) ~= "table" then
        return 0
    end
    local count = 0
    for k, v in pairs(t) do
        count = count + 1
    end
    return count
end

function logFileSize()
  local fd = io.open(logpath, "rb")
  if fd == nil then return end
  local len = fd:seek("end")
  fd:close()
  if len > 1048576 then
    os.remove(logpath)
  end
end

function writelog(msg)
    logFileSize()
    write(logpath, msg, "ab")
end

function file_exists(path)
    local fd = io.open(path, "r")
    if fd ~= nil then
        io.close(fd)
        return true
    else 
        return false
    end
end

function html_file_exists(path)
    local document_root = ngx.var.document_root
    if document_root == nil or path == nil then
        return false
    end
    return file_exists(document_root..path)
end

function log(method, url, data, ruletag)
    if attacklog then
        local realIp = getClientIp()
        local time = ngx.localtime()
        if time == nil then
            time = ""
        end
        if url == nil then
            url = ""
        end
        if string.len(url) > 128 then
            url = string.sub(url, 1, 128)
        end
        if data == nil then
            data = ""
        end
        if string.len(data) > 512 then
            data = string.sub(data, 1, 512)
        end
        if ruletag == nil then
            ruletag = ""
        end
        local line = realIp.." ["..time.."] \""..method.." "..url.."\" \""..data.."\" - \""..ruletag.."\"\n"
        writelog(line)
    end
end

function split(str, character)
    local result = {}
    if str == nil or str == "" then
        return result
    end
    str1 = string.gsub(str, " ", "")
    index = 0
    for s in string.gmatch(str1, "[^"..character.."]+") do
      result[index] = s
      index = index + 1
    end
    return result
end

function accessControlExtItem(fileName, checkItemobj)
    local listArr = split(checkItemobj.fileList, ",")

    local found = 0
    for i, v in pairs(listArr) do 
        if fileName == v then
            found = 1
            break
        end
    end

    if found == 0 then
        return
    else
        if checkItemobj.judgeType == "func" then
            local res = ngx.req.call_webs_func(checkItemobj.judgeCondition)
            if res ~= checkItemobj.judgeResult then
                log("file no premission - [", fileName.." ]", "judgeCondition: "..checkItemobj.judgeCondition.."\" \"judgeResult: "..checkItemobj.judgeResult, "res: "..res)
                ngx.exit(400)
            end
        elseif checkItemobj.judgeType == "devinfo" then
            local res = ngx.req.get_devinfo(checkItemobj.judgeCondition)
            if res ~= checkItemobj.judgeResult then
                log("file no premission - [", fileName.." ]", "judgeCondition: "..checkItemobj.judgeCondition.."\" \"judgeResult: "..checkItemobj.judgeResult, "res: "..res)
                ngx.exit(400)
            end
        end
    end
end

function accessControlExt(fileName, extraCheckObj)
    for key, value in pairs(extraCheckObj) do
        accessControlExtItem(fileName, value)
    end
end

function userPagesAccessControl(publicList, listUser, listArea, listAreaUser, listAreaDel, listAreaUserDel, uri, user, operator_name, area_code, extraCheckObj)
    local fileName = uri:match("([^/]+)$") -- 获取文件名 --
    if fileName == nil or fileName == "" then
        log("no fileName", "-", "-", "-")
        ngx.exit(400)
        return
    end

    local list = ""

    if user > 0 and publicList ~= nil and publicList ~= "" then
        list = list..","..publicList
    end

    if listUser ~= nil and listUser ~= "" then
        list = list..","..listUser
    end

    if user > 0 and listArea ~= nil and listArea ~= "" then
        list = list..","..listArea
    end

    if listAreaUser ~= nil and listAreaUser ~= "" then
        list = list..","..listAreaUser
    end

    if user > 0 and listAreaDel ~= nil and listAreaDel ~= "" then
        local listAreaDelList = split(listAreaDel, ",")
        for i, v in pairs(listAreaDelList) do
            list = string.gsub(list, v, "")
        end
    end

    if listAreaUserDel ~= nil and listAreaUserDel ~= "" then
        local listAreaUserDelList = split(listAreaUserDel, ",")
        for i, v in pairs(listAreaUserDelList) do
            list = string.gsub(list, v, "")
        end
    end

    local listArr = split(list, ",")

    local acc = 0
    for i, v in pairs(listArr) do 
        if fileName == v then
            acc = 1
            break
        end
    end

    if acc == 1 then
        if extraCheckObj then
            accessControlExt(fileName, extraCheckObj)
        else
            return
        end
    else
        log("file no premission - [", fileName.." ]", "user: "..user, operator_name.." "..area_code)
        if string.find(fileName, "%.html") ~= nil then
            ngx.redirect("/", 302)
        else
            ngx.exit(400)
        end
    end
end

local urlrules={}
local argsrules={}
local uarules={}
local postrules={}
local ckrules={}

function read_rule()
    local file = io.open(rulepath, "r")
    if file == nil then
        return
    end
    local typeMode="url"
    for line in file:lines() do
        if line == "*****url*****" then
            typeMode="url"
        elseif line == "*****args*****" then
            typeMode="args"
        elseif line == "*****post*****" then
            typeMode="post"
        elseif line == "*****cookie*****" then
            typeMode="cookie"
        elseif line == "*****user-agent*****" then
            typeMode="user-agent"
        else
            if typeMode == "url" then
                table.insert(urlrules,line)
            elseif typeMode == "args" then
                table.insert(argsrules,line)
            elseif typeMode == "post" then
                table.insert(postrules,line)
            elseif typeMode == "cookie" then
                table.insert(ckrules,line)
            elseif typeMode == "user-agent" then
                table.insert(uarules,line)
            end
        end
    end
    file:close()
end

read_rule()

function forbidden()
    ngx.exit(403)
end

function badRequest()
    ngx.exit(400)
end

function referers()
    if not refererCheck then
        return false
    end

    local http_referer = ngx.var.http_referer
    if http_referer == "" or http_referer == nil then
        return false
    end

    local uri = ngx.var.uri
    if string.find(uri, "^/fh_api/") == nil then
        return false
    end

    local referer_rule = [[\?|\#]]
    if ngxmatch(http_referer, referer_rule, "joi") then
        log('referers', "-", http_referer, referer_rule)
        forbidden()
        return true
    end

    --[[for _,rule in pairs(urlrules) do
        if rule ~= "" and ngxmatch(http_referer, rule, "joi") then
            log('http_referer', "-", http_referer, rule)
            forbidden()
            return true
        end
    end--]]
    return false
end

function args()
    local uri = ngx.var.uri

    --[[只校验自己的接口]]--
    if string.find(uri, "^/fh_api/") == nil and string.find(uri, "^/fh_tool/") == nil then
        return false
    end

    local query_string = ngx.var.query_string
    if query_string == "" or query_string == nil then
        return false
    end

    if ngxmatch(query_string, "=%2F", "joi") then
        ngx.exit(444)
    end

    for _,rule in pairs(argsrules) do
        if rule ~= "" and ngxmatch(query_string, rule, "joi") then
            log('query_string', uri, query_string, rule)
            forbidden()
            return true
        end
    end
    return false
end

function url()
    local request_method = ngx.var.request_method

    --[[只接收post、get报文]]--
    if request_method == "" or request_method == nil then
        log('request_method', "-", 'nil', "-")
        forbidden()
        return true
    end
    if request_method ~= "GET" and request_method ~= "POST" then
        log('request_method', "-", request_method, "not post or get")
        forbidden()
        return true
    end

    if not UrlDeny then
        return false
    end

    local uri = ngx.var.uri
    if uri == "" or uri == nil then
        return false
    end
    for _,rule in pairs(urlrules) do
        if rule ~="" and ngxmatch(uri, rule, "joi") then
            log('uri', uri, "-", rule)
            forbidden()
            return true
        end
    end

    return false
end

function ua()
    local ua = ngx.var.http_user_agent
    if ua == nil or ua == "" then
        return false
    end
    for _,rule in pairs(uarules) do
        if rule ~= "" and ngxmatch(ua, rule, "joi") then
            log('UA', "-", ua, rule)
            forbidden()
            return true
        end
    end

    return false
end

function body()
    local method=ngx.req.get_method()
    local uri = ngx.var.uri

    if method ~= "POST" then
        return false
    end

    --[[不校验升级接口]]--
    if uri == "/fh_api/tmp/FHUPAPIS" then
        return false
    end

    --[[只校验自有web的接口]]--
    if string.find(uri, "^/fh_api/") == nil then
        return false
    end

    ngx.req.read_body()
    local data = ngx.req.get_body_data()
    if data == "" or data == nil then
        return false
    end
    for _,rule in pairs(postrules) do
        if rule ~= "" and ngxmatch(data, rule, "joi") then
            log('POST',"-", data, rule)
            forbidden()
            return true
        end
    end
    return false
end

function cookie()
    if not CookieCheck then
        return false
    end
    local ck = ngx.var.http_cookie
    if ck then
        for _,rule in pairs(ckrules) do
            if rule ~="" and ngxmatch(ck, rule, "joi") then
                log('Cookie', "-", ck, rule)
                local uri = ngx.var.uri
                local query_string = ngx.var.query_string
                ngx.redirect(uri..'?'..query_string, 302)
                return true
            end
        end
    end
    return false
end

-- 10秒钟只允许6次登录请求, 防止扫描工具频繁发包 --
loginApiCCcount = 6
loginApiCCseconds = 10
loginApiNum = 0
loginApiTime = 0
function loginApidenycc()
    local uri = ngx.var.uri
    if uri ~= "/fh_api/sign/DO_WEB_LOGIN" then
        return false
    end
    local uptime = executeCommand("cat /proc/uptime | cut -d ' ' -f 1 | cut -d '.' -f 1")
    local timenum = tonumber(uptime)
    if timenum == nil then
        return false
    end

    -- 超时，初始化登录次数 
    if (timenum - loginApiTime) > loginApiCCseconds and loginApiNum > 0 then
        loginApiNum = 0
        return false
    else
        if loginApiNum >= loginApiCCcount then  -- 达到限制 
            log('loginApidenycc take effect', '-', '-', '-')
            ngx.say('{"result":9,"user":0}')
            return true
        else
            if loginApiNum == 0 then
                loginApiTime = timenum
            end
            loginApiNum = loginApiNum + 1
        end
    end
    return false
end

function denycc()
    if not CCDeny then
        return false
    end
    local query_string = ngx.var.query_string
    if query_string ~= "" and query_string ~= nil and string.find(query_string, "^ajaxmethod=get_refresh_sessionid") == 1 then
        return false
    end
    local uri=ngx.var.uri
    local token = getClientIp()..uri
    local limit = ngx.shared.limit
    local req,_=limit:get(token)
    if req then
        if req > CCcount then
            forbidden()
            return true
        else
            limit:incr(token,1)
        end
    else
        limit:set(token,1,CCseconds)
    end
    return false
end

function encryptoData(data)
    local enData = ngx.encode_base64(data)
    local fileLen = string.len(enData)
    local ran1Len = math.random(11, 41)
    local ran2Len = 5
    local ran3Len = 5
    local inc2 = math.random(11, fileLen - 17)
    local inc3 = fileLen - math.random(0, 15)
    local ran1 = randomString(ran1Len)
    local ran2 = randomString(ran2Len)
    local ran3 = randomString(ran3Len)
    ngx.header["content-len"] = tostring(ran1Len)..tostring(inc2).."."..tostring(inc3)
    return ran1..string.sub(enData, 1, inc2 - 1) .. ran2 .. string.sub(enData, inc2, inc3 - 1) .. ran3 .. string.sub(enData, inc3)
end

function encryptoFile()
    if os.getenv("web_local_proxy") == "0" then
        local data = ""
        local file_path = ngx.var.document_root..ngx.var.uri
        local file = io.open(file_path, "r")
        if file == nil then
            data = ""
        else
            data = file:read("*a")
            file:close()
        end
        if data == nil or string.len(data) < 3 then
            log("get file failed!", "", "uri: ", ngx.var.uri)
            ngx.exit(403)
        end
        ngx.say(encryptoData(data))
    end
end

function fhSetHeadersFilter()
    local uri = ngx.var.uri
    if string.find(uri, "^/plugins/") == 1 or string.find(uri, "^/static/") == 1 then
        ngx.header["Content-Encoding"] = "gzip"
    else
        if string.find(uri, "^/fh_api/download/") == 1 then
            ngx.header["Content-Type"] = "application/octet-stream"
            if ngx.status == 200 then
                local name = nil
                name = ngx.req.get_uri_args()["name"]
                if name ~= nil and name ~= "" and type(name) == "string" then
                    ngx.header["Content-Disposition"] = "attachment; filename*=UTF-8''"..name
                end
            end
        end
    end
end


function initCustomApi(uri, user)
    if uri == "/plugins/polyfill" then
        ngx.redirect("/plugins/polyfill.min.js?_"..math.random(), 302)
    end

    if uri == "/closeTheConsole.html" then
        ngx.say("<!DOCTYPE html><html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/></head><body style='text-align: center;'><h3>Please close the console and return to the page.</h3><a href='javascript: history.go(-1)'>Back</a></body></html>")
        ngx.exit(200)
    end

    if uri == "/lowbrowser.html" then
        ngx.say("<!DOCTYPE html><html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/></head><body style='text-align:center;'><center><h2>Browser version is too low,Please update your browser!</h2><h4>IE >= 9</h4><h4>Firefox >= 21</h4><h4>Chrome >= 23</h4><h4>Safari >= 6.1</h4><h4>Opera >= 15</h4><h4>......</h4></center></body></html>")
        ngx.exit(200)
    end

    -------************ 不需要修改begin ************-------
    if uri == "/fh_api/sign/DO_WEB_LOGIN" then --登录 
        ngx.req.read_body()
        local data = ngx.req.do_web_login()
        ngx.say(data)
        ngx.exit(200)
    end
    if uri == "/fh_api/sign/DO_WEB_LOGOUT" then --登出 
        if user <= 0 then
            ngx.exit(403)
        end
        local data = ngx.req.do_web_logout()
        ngx.say(data)
        ngx.exit(200)
    end
    if uri == "/fh_api/tmp/heartbeat" then --心跳报文、获取登录用户 
        if user <= 0 then
            ngx.status = 418
            ngx.say(user)
            ngx.exit(ngx.status)
        else
            ngx.say(user)
            ngx.exit(200)
        end
    end
    if uri == "/fh_api/tmp/refresh_timeout" then --刷新超时时间 
        if user <= 0 then
            ngx.status = 418
            ngx.say(user)
            ngx.exit(ngx.status)
        else
            ngx.req.refresh_login_time()
            ngx.exit(200)
        end
    end
    if uri == "/fh_api/tmp/other_logged" then --是否已在其他地方登录 是-1, 否-0 
        local data = ngx.req.is_other_ip_logged()
        ngx.say(data)
        ngx.exit(200)
    end
    if uri == "/fh_api/tmp/FHAPIS" or uri == "/fh_api/long/FHAPIS" then  -- 需要登录的接口 
        if user <= 0 then
            forbidden()
        end
    end

    -------************ 不需要修改end ************-------
end

