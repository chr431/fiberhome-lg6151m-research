mount_user_data() {
	mount -t ext4 /dev/block/user_data /data
}
